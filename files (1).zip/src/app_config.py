import json

CONFIG_FILE = "config.json"

def load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {
            "openai_api_key": "",
            "gemini_api_key": "",
            "search_keywords": [],
            "location": "Región Metropolitana, Quinta Región",
            "salary_min": 1000000
        }

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)