import sqlite3

DB_FILE = "appdata.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS postulaciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT,
            portal TEXT,
            cargo TEXT,
            empresa TEXT,
            estado TEXT,
            comentario TEXT
        )
    ''')
    conn.commit()
    conn.close()

def add_postulacion(fecha, portal, cargo, empresa, estado, comentario):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        INSERT INTO postulaciones (fecha, portal, cargo, empresa, estado, comentario)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (fecha, portal, cargo, empresa, estado, comentario))
    conn.commit()
    conn.close()

def get_postulaciones():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('SELECT * FROM postulaciones')
    return c.fetchall()