def parse_cv(cv_text):
    """
    Procesa el texto del CV y extrae información relevante para comparar ofertas laborales.
    """
    # Ejemplo: extraer palabras clave, experiencia, habilidades
    # Aquí puedes incluir lógica NLP más avanzada
    keywords = []
    experiencia = []
    habilidades = []

    # Simulación básica para ejemplo
    for line in cv_text.splitlines():
        if "SAP" in line or "CRM" in line:
            keywords.append(line)
        if "Ejecutivo Comercial" in line or "Asesor Comercial" in line:
            experiencia.append(line)
        if "MS Office" in line or "Hubspot" in line:
            habilidades.append(line)

    return {
        "keywords": keywords,
        "experiencia": experiencia,
        "habilidades": habilidades
    }