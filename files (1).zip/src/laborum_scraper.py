# Base para scraping de Laborum

def search_jobs_laborum(keywords, location, salary_min, limit=50):
    jobs = []
    # Simulación: implementar scraping real aquí
    jobs.append({"title": "Key Account Manager", "company": "Empresa Z", "location": "Santiago", "salary": 1100000, "description": "Gestión de cuentas comerciales"})
    return jobs