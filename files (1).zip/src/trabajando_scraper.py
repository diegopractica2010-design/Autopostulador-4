# Base para scraping de Trabajando.com

def search_jobs_trabajando(keywords, location, salary_min, limit=50):
    jobs = []
    # Simulación: implementar scraping real aquí
    jobs.append({"title": "Jefe Comercial", "company": "Empresa B", "location": "Santiago", "salary": 1400000, "description": "Liderar equipo de ventas"})
    return jobs