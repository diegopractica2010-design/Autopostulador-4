import openai
# import google.generativeai as gemini # Activar si usas Gemini API

def filter_with_openai(job, cv, api_key):
    openai.api_key = api_key
    prompt = f"Mi CV:\n{cv}\nOferta:\n{job['description']}\n¿En qué porcentaje soy compatible con esta oferta? Responde sólo el porcentaje numérico."
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo", messages=[
        {"role": "user", "content": prompt}
    ])
    return extract_percentage(response['choices'][0]['message']['content'])

def filter_with_gemini(job, cv, api_key):
    # Lógica para Gemini API similar a OpenAI
    return 85 # Simulación

def extract_percentage(text):
    # Extrae el porcentaje numérico de la respuesta
    import re
    match = re.search(r'(\d+)', text)
    if match:
        return int(match.group(1))
    return 0

def filter_jobs(jobs, cv_text, api_key, ia="openai", threshold=80):
    filtered = []
    for job in jobs:
        if ia == "openai":
            pct = filter_with_openai(job, cv_text, api_key)
        else:
            pct = filter_with_gemini(job, cv_text, api_key)
        if pct >= threshold:
            job["compatibilidad"] = pct
            filtered.append(job)
    return filtered