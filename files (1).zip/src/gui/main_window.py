from PyQt5.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LinkedIn AutoApply")
        self.setGeometry(100, 100, 1000, 700)
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget(self)
        layout = QVBoxLayout(central_widget)

        self.label = QLabel("Opciones de búsqueda y postulaciones automáticas", self)
        self.table = QTableWidget(self)
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Cargo", "Empresa", "Ubicación", "Salario", "Compatibilidad", "Portal"])

        self.search_button = QPushButton("Buscar Ofertas", self)
        self.apply_button = QPushButton("Postular Automáticamente", self)

        layout.addWidget(self.label)
        layout.addWidget(self.table)
        layout.addWidget(self.search_button)
        layout.addWidget(self.apply_button)

        self.setCentralWidget(central_widget)