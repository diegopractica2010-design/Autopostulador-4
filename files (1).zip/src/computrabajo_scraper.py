# Base para scraping de Computrabajo

def search_jobs_computrabajo(keywords, location, salary_min, limit=50):
    jobs = []
    # Simulación: implementar scraping real aquí
    jobs.append({"title": "Asesor Comercial", "company": "Empresa A", "location": "Viña del Mar", "salary": 1150000, "description": "Asesoría a pymes y emprendedores"})
    return jobs