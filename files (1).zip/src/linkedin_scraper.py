# Simulación de scraping de LinkedIn (requiere Selenium o requests con autenticación)

def search_jobs_linkedin(keywords, location, salary_min, limit=50):
    jobs = []
    # Simulación: puedes implementar scraping real aquí
    jobs.append({"title": "Ejecutivo Comercial", "company": "Empresa X", "location": "Santiago", "salary": 1200000, "description": "Ventas consultivas SAP y CRM"})
    jobs.append({"title": "Consultor SAP", "company": "Empresa Y", "location": "Valparaíso", "salary": 1300000, "description": "Consultoría SAP Business One"})
    return jobs