# LinkedIn AutoApply

Aplicación en Python con GUI avanzada para Xubuntu 24.04.2 LTS que:
- Busca ofertas laborales en LinkedIn, Laborum, Computrabajo y Trabajando.com.
- Filtra ofertas compatibles con tu CV (>80%) usando IA web (OpenAI/Gemini).
- Postula automáticamente, generando cartas de presentación si es necesario.
- Guarda historial de postulaciones y permite pausar/reanudar procesos.

---

## Instalación de dependencias

```bash
sudo apt update
sudo apt install python3 python3-pip git
pip3 install -r requirements.txt
```

## Configuración de API Keys

1. **OpenAI:**  
   - Crea cuenta en [OpenAI](https://platform.openai.com/signup)
   - Ve a [API Keys](https://platform.openai.com/api-keys) y copia tu clave gratuita.
   - Pega la API key en la configuración de la app (o en el archivo `config.json`).

2. **Gemini:**  
   - Crea cuenta en [Google AI Studio](https://aistudio.google.com/)
   - Ve a [API Keys](https://aistudio.google.com/app/apikey) y copia tu clave gratuita.
   - Pega la API key en la configuración de la app.

## Ejecución de la aplicación

```bash
python3 src/main.py
```

## Compilación como AppImage

1. Instala [AppImage Builder](https://appimage-builder.readthedocs.io/en/latest/)
   ```bash
   pip3 install appimage-builder
   ```
2. Ejecuta la compilación:
   ```bash
   appimage-builder --recipe appimage-builder.yml
   ```
   El resultado será un archivo `.AppImage` ejecutable en Xubuntu y otras distros Linux.

## Estructura principal

- `src/` Código fuente
- `assets/` Iconos e imágenes
- `tests/` Pruebas unitarias
- `build/` Compilación AppImage

## Características

- **Filtro de compatibilidad IA:** OpenAI/Gemini gratis (controla uso).
- **GUI avanzada:** Ver ofertas, historial, editar cartas, logs, configuración.
- **Escalabilidad:** Listo para sumar Laborum, Computrabajo, Trabajando.com.
- **Automatización:** Postulación automática, generación de cartas y respuestas frecuentes.

## Notas

- El scraping de portales puede requerir actualización frecuente, según cambios en los sitios.
- El módulo de historial usa SQLite (local).
- El sistema controla el uso de IA para no sobrepasar cuotas gratuitas.